<?php 

echo $_POST['id'];

?>